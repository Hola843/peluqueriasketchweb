"use client";

import { waLink } from "../config";

interface Props {
  variant?: "float" | "inline";
  tone?: "light" | "dark";
  size?: "sm" | "md";
  message?: string;
  label?: string;
  className?: string;
}

function WaIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  );
}

export default function WhatsAppButton({
  variant = "float",
  tone = "light",
  size = "md",
  message,
  label = "WhatsApp",
  className = "",
}: Props) {
  const href = waLink(message);

  if (variant === "inline") {
    const toneCls =
      tone === "dark"
        ? "border-[#faf8f3]/25 text-[#faf8f3] hover:border-[#faf8f3]/60 hover:bg-[#faf8f3]/[0.06]"
        : "border-[#111]/15 text-[#111] hover:border-[#111]/40 hover:bg-[#111]/[0.03]";
    const sizeCls = size === "sm" ? "btn-sm" : "px-5 py-3 text-[11px]";
    const iconCls = size === "sm" ? "w-3.5 h-3.5" : "w-4 h-4";
    return (
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className={`btn border ${toneCls} ${sizeCls} ${className}`}
      >
        <WaIcon className={`${iconCls} text-[#25d366]`} />
        <span>{label}</span>
      </a>
    );
  }

  // Float — small, quiet, no pulsing rings
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Abrir chat de WhatsApp"
      className={`group fixed bottom-5 right-5 z-40 flex items-center gap-3 ${className}`}
    >
      <span className="hidden md:flex items-center pointer-events-none opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 bg-[#111] text-[#faf8f3] px-3 py-2 text-[10px] font-mono tracking-[0.15em] uppercase">
        WhatsApp
      </span>
      <span className="relative flex items-center justify-center w-12 h-12 rounded-full bg-[#25d366] text-white shadow-[0_8px_24px_rgba(0,0,0,0.18)] transition-transform duration-300 group-hover:scale-105 group-active:scale-95">
        <WaIcon className="w-6 h-6" />
      </span>
    </a>
  );
}
