"use client";

/// <reference types="vite/client" />
import { useEffect, useRef, useState } from "react";
import introLogo from "../assets/intro-logo.png";

const CSS = `
.iv-root{position:fixed;inset:0;z-index:300;background:#faf8f3;display:flex;align-items:center;justify-content:center;overflow:hidden}
.iv-dots{position:absolute;inset:0;background-image:radial-gradient(circle, rgba(17,17,17,.05) 1px, transparent 1px);background-size:20px 20px;opacity:.7}
.iv-edge{position:absolute;left:0;right:0;bottom:0;height:3px;background:#7a1f2b;opacity:0}
.iv-col{position:relative;display:flex;flex-direction:column;align-items:center;z-index:2}
.iv-stage{position:relative;width:min(72vw,330px);aspect-ratio:1/1;display:flex;align-items:center;justify-content:center}
.iv-art{position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;opacity:0;transform:scale(.9)}
[data-phase="0"] .iv-art,[data-phase="1"] .iv-art,[data-phase="2"] .iv-art,[data-phase="3"] .iv-art{opacity:1;transform:scale(1);transition:opacity .6s ease, transform .6s cubic-bezier(.2,.8,.2,1)}
.iv-art img{width:100%;height:100%;object-fit:contain;mix-blend-mode:multiply}
.iv-svgwrap{width:80%;height:80%;display:flex;align-items:center;justify-content:center}
.iv-svgwrap svg{width:100%;height:100%}
[data-phase="1"] .iv-art{animation:iv-snip .55s ease}
@keyframes iv-snip{0%{transform:scale(1) rotate(0)}30%{transform:scale(1.05) rotate(-2.5deg)}60%{transform:scale(.98) rotate(1.5deg)}100%{transform:scale(1) rotate(0)}}
.iv-blade{position:absolute;left:-25%;top:50%;width:150%;height:3px;background:linear-gradient(90deg,transparent,#7a1f2b 35%,#7a1f2b 65%,transparent);transform:translateY(-50%) rotate(-26deg) scaleX(0);transform-origin:left center;opacity:0}
[data-phase="1"] .iv-blade{animation:iv-cut .85s cubic-bezier(.6,0,.2,1) forwards}
@keyframes iv-cut{0%{transform:translateY(-50%) rotate(-26deg) scaleX(0);opacity:0}12%{opacity:1}100%{transform:translateY(-50%) rotate(-26deg) scaleX(1);opacity:0}}
.iv-spark{position:absolute;left:50%;top:44%;width:10px;height:10px;border-radius:50%;background:#7a1f2b;opacity:0}
[data-phase="1"] .iv-spark{animation:iv-spark .6s ease .12s}
@keyframes iv-spark{0%{opacity:0;transform:translate(-50%,-50%) scale(0)}40%{opacity:.9;transform:translate(-50%,-50%) scale(2.6)}100%{opacity:0;transform:translate(-50%,-50%) scale(.3)}}
.iv-strand{position:absolute;top:48%;width:2px;height:24px;background:#111;border-radius:2px;opacity:0}
[data-phase="1"] .iv-strand,[data-phase="2"] .iv-strand{animation:iv-fall 1.15s ease forwards}
@keyframes iv-fall{0%{opacity:0;transform:translateY(0) rotate(0)}20%{opacity:.65}100%{opacity:0;transform:translateY(130px) rotate(20deg)}}
.iv-brand{margin-top:-6px;text-align:center}
.iv-name{font-family:'Bebas Neue','Fraunces',serif;font-size:clamp(2.8rem,13vw,5.2rem);letter-spacing:.16em;color:#111;line-height:.9;display:inline-flex}
.iv-name span{display:inline-block;opacity:0;transform:translateY(45%)}
[data-phase="2"] .iv-name span,[data-phase="3"] .iv-name span{animation:iv-letter .6s cubic-bezier(.2,.8,.2,1) forwards}
@keyframes iv-letter{to{opacity:1;transform:translateY(0)}}
.iv-rule{height:2px;width:0;margin:8px auto 0;background:#7a1f2b}
[data-phase="2"] .iv-rule,[data-phase="3"] .iv-rule{animation:iv-rule .7s ease .4s forwards}
@keyframes iv-rule{to{width:70%}}
.iv-tag{font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:.34em;color:rgba(17,17,17,.5);margin-top:8px;opacity:0}
[data-phase="2"] .iv-tag,[data-phase="3"] .iv-tag{animation:iv-fade .6s ease .7s forwards}
@keyframes iv-fade{to{opacity:1}}
.iv-bar{position:absolute;left:0;right:0;bottom:0;height:2px;background:rgba(17,17,17,.08);z-index:3}
.iv-bar span{display:block;height:100%;width:100%;background:#7a1f2b;transform:scaleX(0);transform-origin:left center;animation:iv-prog 3s linear forwards}
@keyframes iv-prog{to{transform:scaleX(1)}}
.iv-skip{position:absolute;right:18px;bottom:16px;z-index:4;font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:.2em;color:rgba(17,17,17,.45);background:none;border:1px solid rgba(17,17,17,.18);border-radius:999px;padding:6px 12px;cursor:pointer;transition:color .25s,border-color .25s}
.iv-skip:hover{color:#7a1f2b;border-color:#7a1f2b}
[data-phase="3"] .iv-root,[data-phase="3"].iv-root{animation:iv-out .7s cubic-bezier(.7,0,.3,1) forwards}
.iv-root[data-phase="3"]{animation:iv-out .7s cubic-bezier(.7,0,.3,1) forwards}
.iv-root[data-phase="3"] .iv-edge{opacity:1}
@keyframes iv-out{to{transform:translateY(-101%)}}
@media (prefers-reduced-motion: reduce){
  .iv-art{opacity:1!important;transform:none!important}
  .iv-name span{opacity:1!important;transform:none!important}
  .iv-rule{width:70%!important}
  .iv-tag{opacity:1!important}
  .iv-blade,.iv-spark,.iv-strand,.iv-bar{display:none!important}
  .iv-root[data-phase="3"]{animation:iv-fade .3s ease forwards}
}
`;

// Emblema vectorial de reserva (mismo estilo que el logo): se muestra si no
// existe /intro-scissors.png. Para usar el logo real, guarda el PNG ahí.
const EMBLEM = (
  <svg viewBox="0 0 400 400" aria-hidden>
    <circle cx="200" cy="200" r="182" fill="none" stroke="#111" strokeWidth="7" />
    <g fill="#111">
      <path d="M178,232 C170,210 166,182 170,152 C173,122 188,98 214,96 C236,94 250,106 252,124 C253,134 248,138 242,140 C249,146 251,152 248,158 C262,162 264,170 256,173 C252,175 250,178 253,183 C258,190 258,200 250,210 C242,222 226,232 210,230 C200,229 192,224 188,216 C184,224 182,230 178,232 Z" />
      <path d="M196,100 C206,74 244,76 254,100 C242,90 214,90 202,104 Z" />
    </g>
    <g stroke="#111" strokeWidth="3" strokeLinecap="round">
      <line x1="70" y1="186" x2="120" y2="186" />
      <line x1="70" y1="222" x2="120" y2="222" />
      <line x1="280" y1="186" x2="330" y2="186" />
      <line x1="280" y1="222" x2="330" y2="222" />
    </g>
    <g fill="#111" stroke="none" fontFamily="'Manrope',sans-serif" fontWeight="700">
      <text x="95" y="210" textAnchor="middle" fontSize="20" letterSpacing="2">EST.</text>
      <text x="305" y="210" textAnchor="middle" fontSize="20" letterSpacing="2">2024</text>
    </g>
    <text x="200" y="288" textAnchor="middle" fill="#111" fontFamily="'Bebas Neue','Oswald',sans-serif" fontSize="52" letterSpacing="4">BARBERÍA</text>
    <g stroke="#111" strokeWidth="3" strokeLinecap="round">
      <line x1="120" y1="312" x2="150" y2="312" />
      <line x1="250" y1="312" x2="280" y2="312" />
    </g>
    <text x="200" y="318" textAnchor="middle" fill="#111" fontFamily="'Manrope',sans-serif" fontWeight="700" fontSize="20" letterSpacing="7">MASCULINA</text>
    <g stroke="#111" strokeWidth="6" strokeLinecap="round">
      <line x1="162" y1="372" x2="232" y2="340" />
      <line x1="238" y1="372" x2="168" y2="340" />
    </g>
    <g fill="#111">
      <ellipse cx="236" cy="338" rx="15" ry="4" transform="rotate(-24 236 338)" />
      <ellipse cx="164" cy="338" rx="15" ry="4" transform="rotate(24 164 338)" />
      <circle cx="162" cy="372" r="4" />
      <circle cx="238" cy="372" r="4" />
    </g>
  </svg>
);

const STRANDS = [
  { left: "37%", delay: ".10s" },
  { left: "45%", delay: ".26s" },
  { left: "51%", delay: ".16s" },
  { left: "58%", delay: ".34s" },
  { left: "64%", delay: ".22s" },
];

export default function Intro({ onDone }: { onDone: () => void }) {
  const [show, setShow] = useState(false);
  const [phase, setPhase] = useState(0);
  const [imgOk, setImgOk] = useState<boolean | null>(null);
  const done = useRef(false);
  const reduced =
    typeof window !== "undefined" &&
    typeof window.matchMedia === "function" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const onDoneRef = useRef(onDone);
  useEffect(() => { onDoneRef.current = onDone; }, [onDone]);

  // Se reproduce en cada carga de la página (una vez por montaje de la app).
  useEffect(() => {
    setShow(true);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const finish = () => {
      if (done.current) return;
      done.current = true;
      document.body.style.overflow = prevOverflow;
      onDoneRef.current();
    };
    (window as any).__velureIntroSkip = finish;

    if (reduced) {
      setPhase(2);
      const t = window.setTimeout(finish, 800);
      return () => { clearTimeout(t); document.body.style.overflow = prevOverflow; };
    }

    const t1 = window.setTimeout(() => setPhase(1), 350);
    const t2 = window.setTimeout(() => setPhase(2), 1500);
    const t3 = window.setTimeout(() => setPhase(3), 3050);
    const t4 = window.setTimeout(finish, 3800);
    return () => {
      [t1, t2, t3, t4].forEach(clearTimeout);
      document.body.style.overflow = prevOverflow;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!show) return null;

  const skip = () => (window as any).__velureIntroSkip?.();

  return (
    <div className="iv-root" data-phase={phase}>
      <style>{CSS}</style>
      <div className="iv-dots" />
      <div className="iv-edge" />

      <div className="iv-col">
        <div className="iv-stage">
          {STRANDS.map((s, i) => (
            <span key={i} className="iv-strand" style={{ left: s.left, animationDelay: s.delay }} />
          ))}
          <div className="iv-art">
            <img
              src={introLogo}
              alt="Barbería Masculina · EST. 2024"
              onLoad={() => setImgOk(true)}
              onError={() => setImgOk(false)}
              style={{ display: imgOk === false ? "none" : "block" }}
            />
            <div className="iv-svgwrap" style={{ display: imgOk === false ? "flex" : "none" }}>
              {EMBLEM}
            </div>
            <div className="iv-blade" />
            <div className="iv-spark" />
          </div>
        </div>

        <div className="iv-brand">
          <div className="iv-name">
            {"VELURE".split("").map((c, i) => (
              <span key={i} style={{ animationDelay: `${1.5 + i * 0.07}s` }}>{c}</span>
            ))}
          </div>
          <div className="iv-rule" />
          <div className="iv-tag">MADRID</div>
        </div>
      </div>

      <div className="iv-bar"><span /></div>
      <button className="iv-skip" onClick={skip}>SALTAR</button>
    </div>
  );
}
