// ─── Sincronización directa con calendarios nativos ────────────────────────
// Compatible con: Apple Calendar (iOS/macOS), Google Calendar, Outlook
// En móvil: abre la app de calendario nativa al instante
// ────────────────────────────────────────────────────────────────────────────

import { SALON } from "../config";

// Una sola fuente de verdad: todo se lee de src/config.ts
export const OWNER_EMAIL = SALON.ownerEmail;
export const SALON_NAME = `${SALON.name} ${SALON.tagline}`;
export const SALON_ADDRESS = SALON.address;
export const SALON_PHONE = SALON.phoneDisplay;

export interface CalendarEvent {
  title: string;
  description: string;
  location: string;
  startDate: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
  organizer?: string;
  attendees?: string[];
  uid?: string;
}

// ─── Generar contenido .ics ────────────────────────────────────────────────

function formatICSDate(date: string, time: string): string {
  const [y, m, d] = date.split("-");
  const [hh, mm] = time.split(":");
  return `${y}${m}${d}T${hh}${mm}00`;
}

function escapeICS(text: string): string {
  return text
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\n/g, "\\n")
    .replace(/\r/g, "");
}

export function generateICSContent(event: CalendarEvent): string {
  const uid = event.uid || `${Date.now()}-${Math.random().toString(36).slice(2)}@velurestudio.com`;
  const start = formatICSDate(event.startDate, event.startTime);
  const end = formatICSDate(event.startDate, event.endTime);
  const now = new Date().toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";

  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//VELURE Studio//ES",
    "CALSCALE:GREGORIAN",
    "METHOD:REQUEST",
    "BEGIN:VEVENT",
    `UID:${uid}`,
    `DTSTAMP:${now}`,
    `DTSTART:${start}`,
    `DTEND:${end}`,
    `SUMMARY:${escapeICS(event.title)}`,
    `DESCRIPTION:${escapeICS(event.description)}`,
    `LOCATION:${escapeICS(event.location)}`,
    "STATUS:CONFIRMED",
    "SEQUENCE:1",
  ];

  // Organizer
  lines.push(`ORGANIZER;CN=${escapeICS(SALON_NAME)}:mailto:${OWNER_EMAIL}`);

  // Attendees - siempre incluir a la dueña
  const allAttendees = event.attendees ? [...event.attendees] : [];
  if (!allAttendees.includes(OWNER_EMAIL)) {
    allAttendees.unshift(OWNER_EMAIL);
  }
  allAttendees.forEach((email) => {
    lines.push(`ATTENDEE;CUTYPE=INDIVIDUAL;ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION;RSVP=TRUE:mailto:${email}`);
  });

  // Alarma 15 min antes
  lines.push(
    "BEGIN:VALARM",
    "TRIGGER:-PT15M",
    "ACTION:DISPLAY",
    "DESCRIPTION:🔔 Recordatorio: Cita en VELURE Studio",
    "END:VALARM"
  );

  lines.push("END:VEVENT", "END:VCALENDAR");
  return lines.join("\r\n");
}

// ─═══ MÉTODO PRINCIPAL: Abrir directamente la app de calendario ════

/**
 * Abre el archivo .ics directamente en el navegador usando una Data URI.
 * 
 * ✅ En iPhone (Safari): abre al instante "Añadir al Calendario" 
 * ✅ En Android (Chrome): abre Google Calendar con el evento pre-cargado
 * ✅ En escritorio: descarga el archivo .ics
 * 
 * Esto es lo más cercano a "automático" sin un servidor backend.
 */
export function openInCalendarApp(event: CalendarEvent): void {
  const icsContent = generateICSContent(event);
  
  // Intentar con Data URI (funciona en iOS Safari y Android Chrome)
  const encoded = encodeURIComponent(icsContent);
  const dataUri = `data:text/calendar;charset=utf-8,${encoded}`;
  
  // Abrir en nueva pestaña/ventana
  // En iOS Safari, esto abre directamente el prompt "Añadir al Calendario"
  // En Android, abre Google Calendar o la app nativa de calendario
  const win = window.open(dataUri, "_blank");
  
  // Fallback: si no se pudo abrir (popup blocker), descargar como archivo
  if (!win || win.closed || typeof win.closed === 'undefined') {
    downloadICSFile(event, `velure-${event.startDate}.ics`);
  }
}

/**
 * Versión mejorada que primero intenta la Data URI y si falla,
 * fuerza la descarga del .ics
 */
export function syncToOwnerCalendar(event: CalendarEvent): void {
  openInCalendarApp(event);
}

// ─═══ MÉTODO ALTERNATIVO: Google Calendar ════

/**
 * Genera enlace a Google Calendar con la dueña como invitada
 */
export function generateGoogleCalendarLink(event: CalendarEvent): string {
  const fmt = (date: string, time: string) => {
    const [y, m, d] = date.split("-");
    const [hh, mm] = time.split(":");
    return `${y}${m}${d}T${hh}${mm}00`;
  };

  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: event.title,
    dates: `${fmt(event.startDate, event.startTime)}/${fmt(event.startDate, event.endTime)}`,
    details: event.description,
    location: event.location,
    trp: "false",
    sf: "true",
    output: "xml",
  });

  // Añadir dueña como invitada
  const allAttendees = event.attendees ? [...event.attendees] : [];
  if (!allAttendees.includes(OWNER_EMAIL)) {
    allAttendees.unshift(OWNER_EMAIL);
  }
  allAttendees.forEach((email) => params.append("add", email));

  return `https://www.google.com/calendar/render?${params.toString()}`;
}

// ─═══ MÉTODO DE RESPALDO: Descargar archivo .ics ════

/**
 * Descarga un archivo .ics
 */
export function downloadICSFile(event: CalendarEvent, filename = "cita-velure.ics") {
  const content = generateICSContent(event);
  const blob = new Blob([content], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ─═══ MÉTODO: Email a la dueña ════

/**
 * Abre el cliente de correo con la cita lista
 * Incluye el .ics como texto y el enlace a Google Calendar
 */
export function generateOwnerMailTo(event: CalendarEvent): string {
  const subject = encodeURIComponent(`📅 Nueva Cita VELURE: ${event.title}`);
  
  const bodyLines = [
    `🆕 NUEVA CITA RESERVADA EN VELURE`,
    `━━━━━━━━━━━━━━━━━━━━━━━`,
    ``,
    `👤 Cliente: ${event.title}`,
    `📅 Fecha: ${event.startDate}`,
    `⏰ Hora: ${event.startTime} - ${event.endTime}`,
    `📍 Dirección: ${event.location}`,
    ``,
    `📝 Notas:`,
    event.description,
    ``,
    `━━━━━━━━━━━━━━━━━━━━━━━`,
    `🌐 Añadir a Google Calendar:`,
    generateGoogleCalendarLink(event),
    ``,
    `━━━━━━━━━━━━━━━━━━━━━━━`,
    `VELURE Studio - Sistema de Reservas Automáticas`,
  ];
  
  const body = encodeURIComponent(bodyLines.join("\n"));
  return `mailto:${OWNER_EMAIL}?subject=${subject}&body=${body}`;
}

// ─═══ HELPERS ════

/**
 * Crea un evento de calendario a partir de una cita
 */
export function createCalendarEvent(
  clientName: string,
  serviceLabel: string,
  date: string,
  time: string,
  phone: string,
  email: string,
  notes: string,
  code: string,
): CalendarEvent {
  const endHour = parseInt(time.split(":")[0]) + 1;
  const endTime = `${String(endHour).padStart(2, "0")}:${time.split(":")[1]}`;

  return {
    title: `✂️ ${clientName} - ${serviceLabel}`,
    description: [
      `👤 Cliente: ${clientName}`,
      `📞 Teléfono: ${phone}`,
      `✉️ Email: ${email}`,
      `💇 Servicio: ${serviceLabel}`,
      `📝 Notas: ${notes || "Sin notas"}`,
      `🔑 Código: ${code}`,
      ``,
      `📍 ${SALON_ADDRESS}`,
      `📞 ${SALON_PHONE}`,
    ].join("\n"),
    location: SALON_ADDRESS,
    startDate: date,
    startTime: time,
    endTime,
    organizer: OWNER_EMAIL,
    attendees: [OWNER_EMAIL, email],
  };
}
