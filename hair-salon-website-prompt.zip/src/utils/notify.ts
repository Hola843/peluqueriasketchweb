import type { Appointment } from "../types";
import { NOTIFICATIONS, SALON } from "../config";
import { formatDateDisplay } from "../store";

/** URL del panel que va dentro del email. Si no se fija en config, se usa la
 *  URL donde esté publicada la web + #admin (deep-link al login del panel). */
export function buildAdminUrl(): string {
  if (NOTIFICATIONS.adminUrl) return NOTIFICATIONS.adminUrl;
  if (typeof window === "undefined") return "";
  // Ruta /admin (con rewrite en vercel.json): es lo que mejor sobrevive en
  // móviles y visores in-app, que suelen recortar tanto "?..." como "#...".
  return `${window.location.origin}/admin`;
}

export interface NotifyResult {
  ok: boolean;
  via: "emailjs" | "formsubmit" | "none";
  error?: string;
}

/**
 * Avisa al peluquero (SALON.ownerEmail) cuando entra una cita nueva.
 *  1) EmailJS, si está configurado (email con plantilla + botón al panel).
 *  2) FormSubmit, si EmailJS está vacío (sin registro; confirma el correo 1 vez).
 * El envío es silencioso para el cliente que reserva.
 */
export async function notifyOwnerNewAppointment(
  a: Appointment,
  serviceLabel: string
): Promise<NotifyResult> {
  const adminUrl = buildAdminUrl();
  const dateLabel = formatDateDisplay(a.date);
  const code = a.id.slice(-6).toUpperCase();
  const subject = `Nueva cita · ${a.clientName} · ${dateLabel} ${a.time}`;

  const fields: Record<string, string> = {
    Cliente: a.clientName,
    Email: a.clientEmail,
    Telefono: a.clientPhone || "—",
    Servicio: serviceLabel,
    Fecha: dateLabel,
    Hora: a.time,
    Codigo: code,
    Notas: a.notes || "—",
    "Panel de administracion": adminUrl,
  };

  // ── 1) EmailJS ────────────────────────────────────────────────────────
  const ej = NOTIFICATIONS.emailjs;
  if (ej.serviceId && ej.templateId && ej.publicKey) {
    try {
      const params: Record<string, string> = {
        to_email: SALON.ownerEmail,
        subject,
        panel_admin: adminUrl,
      };
      for (const [k, v] of Object.entries(fields)) {
        params[k.toLowerCase().replace(/\s+/g, "_")] = v;
      }
      const res = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          service_id: ej.serviceId,
          template_id: ej.templateId,
          user_id: ej.publicKey,
          template_params: params,
        }),
      });
      if (res.ok) return { ok: true, via: "emailjs" };
    } catch {
      /* sigue a la vía 2 */
    }
  }

  // ── 2) FormSubmit (sin registro) ──────────────────────────────────────
  try {
    const body = new FormData();
    body.append("_subject", subject);
    body.append("_captcha", "false");
    body.append("_template", "table");
    // para que el peluquero pueda responder directamente al cliente
    body.append("name", a.clientName);
    body.append("email", a.clientEmail);
    for (const [k, v] of Object.entries(fields)) body.append(k, v);

    const res = await fetch(
      `https://formsubmit.co/ajax/${encodeURIComponent(SALON.ownerEmail)}`,
      { method: "POST", body }
    );
    if (res.ok) return { ok: true, via: "formsubmit" };
  } catch {
    /* no hay más vías sin backend */
  }

  // eslint-disable-next-line no-console
  console.warn("[VELURE] No se pudo avisar por email al peluquero.", { subject });
  return { ok: false, via: "none" };
}
