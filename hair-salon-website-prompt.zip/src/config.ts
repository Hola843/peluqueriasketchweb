// ─── Configuración central del salón ───────────────────────────────────────
// Edita aquí teléfono, WhatsApp, dirección y coordenadas. Toda la web
// (botones de WhatsApp, mapa, enlaces "cómo llegar", recordatorios) lee de
// este archivo. Cambia los valores y se propagan solos.

export const SALON = {
  name: "VELURE",
  tagline: "BARBER CO.",
  // Teléfono tal como se muestra en la web
  phoneDisplay: "+34 912 345 678",
  // Número para wa.me y tel: SIN espacios, guiones ni "+"
  phoneRaw: "34912345678",
  // Número de WhatsApp del salón (para wa.me). Formato internacional sin "+".
  whatsappNumber: "34912345678",
  whatsappDefaultMessage:
    "Hola, quiero reservar una cita en VELURE Barber Co.",
  // Dirección física
  address: "Calle de la Belleza, 42, 28001 Madrid",
  // Coordenadas para el mapa y el enlace "cómo llegar"
  // (pon aquí las coordenadas reales de tu local)
  lat: 40.42001,
  lng: -3.70256,
  email: "hola@velurebarber.co",
  ownerEmail: "martingonzalezfonseca96@gmail.com",
} as const;

// ─── Helpers ───────────────────────────────────────────────────────────────

/** Normaliza un teléfono a formato wa.me (asume +34 si vienen 9 dígitos). */
export function normalizePhone(raw: string): string {
  const digits = raw.replace(/[^\d]/g, "");
  if (digits.length === 9) return "34" + digits; // España por defecto
  if (digits.length === 12 && digits.startsWith("34")) return digits;
  return digits || SALON.whatsappNumber;
}

/** Enlace directo a un chat de WhatsApp con mensaje pre-rellenado. */
export function waLink(
  message: string = SALON.whatsappDefaultMessage,
  phone: string = SALON.whatsappNumber
): string {
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}

/** Mensaje de recordatorio 48h antes, con opciones de confirmar/cancelar. */
export function waReminderMessage(
  clientName: string,
  dateLabel: string,
  time: string
): string {
  return (
    `Hola ${clientName}, te escribimos de ${SALON.name} ${SALON.tagline} ` +
    `para recordar tu cita el ${dateLabel} a las ${time}. ` +
    `¿Nos la confirmas? Responde SÍ para confirmar o NO para cancelarla. ¡Gracias!`
  );
}

/** Mensaje que envía el cliente al reservar (botones de WhatsApp públicos). */
export function waBookingMessage(service?: string, date?: string, time?: string): string {
  const base = SALON.whatsappDefaultMessage;
  if (service || date || time) {
    return `${base} Me interesa: ${service || "—"}${date ? `, ${date}` : ""}${time ? ` a las ${time}` : ""}.`;
  }
  return base;
}

// ─── Mapas ─────────────────────────────────────────────────────────────────

export const MAPS_EMBED_URL =
  `https://www.google.com/maps?q=${SALON.lat},${SALON.lng}&z=16&output=embed`;

// Ruta desde la ubicación del usuario. Destinado con la DIRECCIÓN codificada:
// en móvil, https://www.google.com/maps/dir/?api=1 abre la app de Google Maps
// si está instalada (y la versión web si no); en escritorio abre Maps web.
// Si quieres máxima precisión del pin, cambia el destino a `${SALON.lat},${SALON.lng}`
// o a un place_id de Google.
export const MAPS_DIR_URL =
  `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(SALON.address)}`;

// ─── Notificaciones por email al peluquero ─────────────────────────────────
// Cuando un cliente reserva desde la web, se avisa por email a SALON.ownerEmail
// con los datos de la cita y un enlace directo al panel (#admin).
//
// Vía 1 (recomendada · email con plantilla y botón al panel): EmailJS.
//   Regístrate en emailjs.com, crea un "Email Service" y un "Template" con estas
//   variables: {{to_email}} {{subject}} {{cliente}} {{email}} {{telefono}}
//   {{servicio}} {{fecha}} {{hora}} {{codigo}} {{notas}} {{panel_admin}}
//   En "To Email" del template pon {{to_email}}. Copia Service ID, Template ID
//   y Public Key aquí abajo.
// Vía 2 (cero registro): si dejas emailjs vacío, se usa FormSubmit con
//   ownerEmail. La PRIMERA vez FormSubmit te manda un correo de confirmación:
//   pulsa "Confirm" y a partir de ahí funciona solo.
export const NOTIFICATIONS = {
  emailjs: {
    serviceId: "",
    templateId: "",
    publicKey: "",
  },
  // Si lo dejas vacío, el enlace al panel se construye con la URL publicada + #admin.
  adminUrl: "",
} as const;
