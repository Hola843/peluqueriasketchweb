# VELURE · Barber Co.

Web de una barbería de barrio con reserva de cita online, panel de administración y recordatorios por WhatsApp. Diseño editorial claro (tinta / papel / burdeos) con tipografía *Fraunces* + *Manrope* + *JetBrains Mono*.

> Stack: **React 19 + Vite 7 + TypeScript + Tailwind CSS 4**. El build usa `vite-plugin-singlefile`, así que `npm run build` genera un único `dist/index.html` autocontenido (JS y CSS inlineados). Las fotos se sirven desde Pexels por URL y el favicon es un SVG en data-URI, por lo que el `index.html` resultante es totalmente portable.

---

## Estructura que importa

```
src/
├── App.tsx                  # composición de la web pública (hero, carta, galería,
│                            # voces, reservas, ubicación, cierre)
├── config.ts                # ⬅ TODOS los datos editables del salón
├── components/
│   ├── BookingCalendar.tsx  # reserva paso a paso (servicio → fecha → hora → datos)
│   ├── AdminPanel.tsx       # panel interno + recordatorios 48h + login
│   └── WhatsAppButton.tsx   # botón flotante / inline de WhatsApp
├── store.ts                 # persistencia en localStorage (citas + sesión admin)
├── types.ts                 # tipos, horarios, lista de servicios
└── utils/calendar.ts        # .ics / Google Calendar / mensajes de recordatorio
```

---

## Configura tus datos antes de publicar

Los datos que vienen de serie son de **demo**. Cámbialos en un solo sitio:

- **`src/config.ts`** → dirección real, `phoneDisplay` / `phoneRaw`, `whatsappNumber` (formato internacional **sin** `+` ni espacios, p. ej. `34600000000`), `email`, y `lat` / `lng` reales de tu local (afectan al mapa y al botón *Cómo llegar*).
- **`src/utils/calendar.ts`** → `OWNER_EMAIL` (a quién se invita al evento de Google Calendar).
- **`src/store.ts`** → `ADMIN_PASSWORD` (la contraseña del panel de administración; la de serie es `velure2024`).

---

## Desarrollo local

```bash
npm install
npm run dev      # servidor local
npm run build    # genera dist/index.html
npm run preview  # preview del build
```

---

## Publicar en Vercel (recomendado: desde GitHub)

Esta vía te da **deploy automático en cada `push` a `main`**.

1. Sube el proyecto a tu repo (si aún no está):

   ```bash
   git init
   git branch -M main
   git remote add origin https://github.com/ismael59ramos-svg/web_peluquer-a.git
   git add .
   git commit -m "VELURE Barber Co."
   git push -u origin main
   ```

   > Si el repo ya tenía un commit inicial (README, .gitignore de GitHub, etc.) y el `push` se rechaza, haz antes
   > `git pull origin main --allow-unrelated-histories` y resuelve conflictos, o clona el repo y copia los archivos del proyecto dentro.

2. Entra en [vercel.com](https://vercel.com) → *Sign in with GitHub* → **Add New Project** → importa `web_peluquer-a`.
3. Vercel detecta **Vite** automáticamente. Verifica (normalmente ya viene rellenado):
   - Framework Preset: `Vite`
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. **Deploy**. Te da una URL `*.vercel.app`. A partir de ahí, cada push a `main` redeploya solo.
5. (Opcional) *Settings → Domains* para conectar tu dominio propio.

### Alternativa: Vercel CLI

```bash
npm i -g vercel
vercel login
vercel            # wizard de primera configuración
vercel --prod     # despliega a producción
```

---

## Nota sobre `vite-plugin-singlefile`

Con el plugin activo, todo el sitio vive en un único `index.html`, así que funciona en Vercel sin configurar assets. Si más adelante quisieras aprovechar el cacheo de Vercel por archivo (hashes en JS/CSS), se puede retirar el plugin de `vite.config.ts`; no es necesario para publicar.

---

## Panel de administración

Acceso desde el enlace *Acceso interno* del pie de página. Permite ver todas las citas, añadirlas a mano, cancelarlas, enviar recordatorios por WhatsApp a 48 h y consultar los pasos para automatizar esos recordatorios con Meta / Twilio (requiere backend).

---

## Email al peluquero cuando entra una cita

Cuando un cliente reserva desde la web, el sitio avisa por email a `SALON.ownerEmail` con los datos (cliente, contacto, servicio, fecha, hora y código) y un **enlace directo al panel** (`…/?admin=1`, que abre la web en el login del panel; `#admin` también vale). El envío es silencioso para el cliente. No hace falta backend: se usa un *relay* de email desde el navegador, con dos vías configurables en `src/config.ts` → `NOTIFICATIONS`:

- **EmailJS (recomendada)** — email con plantilla y botón al panel. Crea cuenta en [emailjs.com](https://www.emailjs.com), un *Email Service* y un *Template* con estas variables: `{{to_email}} {{subject}} {{cliente}} {{email}} {{telefono}} {{servicio}} {{fecha}} {{hora}} {{codigo}} {{notas}} {{panel_admin}}`. En *To Email* del template pon `{{to_email}}`. Copia *Service ID*, *Template ID* y *Public Key* en `NOTIFICATIONS.emailjs`.
- **FormSubmit (cero registro)** — si dejas `NOTIFICATIONS.emailjs` vacío, se usa FormSubmit con `ownerEmail`. **La primera vez** te llegará un correo de FormSubmit: pulsa *Confirm* para activarlo; después funciona solo.

> Las citas creadas a mano **desde el panel no** disparan email, para no enviarte avisos de tus propias citas. Si cambias de dominio, fija la URL completa en `NOTIFICATIONS.adminUrl`.

---

## Almacenamiento en la nube + recordatorios automáticos

**Sin configurar nada**, la web guarda las citas en el navegador (`localStorage`): vale para probar, pero una cita hecha en un móvil **no** aparece en otro dispositivo ni en el panel abierto en otro sitio. Para que las citas vivan en la web (visibles desde cualquier sitio) y para mandar el **recordatorio 24 h antes** por SMS/WhatsApp, conecta Supabase + Twilio con los pasos de abajo. Mientras no lo hagas, todo sigue funcionando como hasta ahora.

### 1 · Supabase (las citas en la nube)
1. Crea cuenta y proyecto en [supabase.com](https://supabase.com) (gratis).
2. **SQL Editor** → pega y ejecuta **todo** el contenido de `supabase/schema.sql`.
3. Crea tu usuario de dueño: **Authentication → Users → Add user** con el email y la contraseña con los que entrarás al panel (si sale “auto confirm”, márcalo). Cuando la nube esté activa, el panel te pedirá **ese** email/contraseña en lugar de la contraseña local.
4. **Settings → API** → copia la **Project URL** y la clave **anon / public**.
5. En Vercel: tu proyecto → **Settings → Environment Variables**, añade:
   - `VITE_SUPABASE_URL` = la Project URL
   - `VITE_SUPABASE_ANON_KEY` = la clave anon
   - `SUPABASE_SERVICE_ROLE_KEY` = la clave **service_role** (⚠️ secreta; **sin** prefijo `VITE_`; la usa el cron de recordatorios, nunca el cliente)

   > El prefijo `VITE_` es obligatorio para las dos primeras (son las que ve la web). La `service_role` jamás lleva `VITE_`.

### 2 · Recordatorios 24 h antes (Twilio)
1. Cuenta en [twilio.com](https://twilio.com) (tiene saldo de prueba). En el Dashboard copia **Account SID** y **Auth Token**, y ten un número origen (From).
2. En Vercel Environment Variables añade:
   - `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`
   - `TWILIO_FROM` = número origen en formato internacional (`+34…` o el de Twilio)
   - `REMINDER_CHANNEL` = `sms` (recomendado) o `whatsapp`
   - `TWILIO_WA_FROM` = solo si usas `whatsapp` (tu número WhatsApp de Twilio, `+34…`)
   - `CRON_SECRET` = una frase aleatoria que inventes (protege el endpoint; Vercel la usa para disparar el cron)

   > **WhatsApp oficial** (Meta/Twilio) exige una *plantilla aprobada por Meta* para los mensajes que inicias tú. Si quieres WhatsApp **ya** sin aprobar plantilla, usa un proveedor por QR como **UltraMsg**: añade `ULTRAMSG_INSTANCE` y `ULTRAMSG_TOKEN` y pon `REMINDER_CHANNEL=whatsapp` (texto libre; respeta frecuencias para no arriesgar el número).

3. El cron ya viene en `vercel.json` (`/api/reminders` cada hora): avisa a las citas que empiezan en ~24 h y aún no se avisaron.

### 3 · Publica
```bash
git add .
git commit -m "Nube + recordatorios"
git push
```
Vercel redeploya solo. Con las `VITE_*` puestas, la web guarda en Supabase; el panel te pedirá el email/contraseña del dueño; y el cron enviará los recordatorios.

### Cómo comprobarlo
- **Reserva** una cita → aparece en Supabase (Table Editor → `appointments`).
- **Panel** con el email/contraseña del dueño → ves la cita desde cualquier dispositivo.
- **Recordatorio ya**: espera a que una cita caiga en la ventana de 24 h, o dispáralo a mano:
  ```bash
  curl -H "Authorization: Bearer TU_CRON_SECRET" https://TU-PROYECTO.vercel.app/api/reminders
  ```
  (solo envía a las citas a ~24 h sin avisar).

### Seguridad y limitaciones
- La clave `anon` es pública por diseño; los datos personales de los clientes **no** se exponen al público gracias a las políticas RLS y a las funciones `booked_slots` / `booked_counts` del schema, que solo devuelvan fechas y horas (nunca nombres, emails o teléfonos).
- Con la nube activa, el calendario público consulta los huecos ocupados a la nube, así que **no se duplican reservas** entre dispositivos.
- Sin nube, rige lo de siempre: las citas viven en el navegador; usa “Abrir en Chrome/Safari” desde el email, no el visor interno de la app de correo.

---

Hecho con tijera y paciencia. ✂
