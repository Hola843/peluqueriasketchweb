-- ─── VELURE Barber Co. · esquema de Supabase ───────────────────────────────
-- Ejecuta TODO este bloque en el SQL Editor de tu proyecto Supabase
-- (https://supabase.com/dashboard → tu proyecto → SQL Editor → New query).
--
-- Qué crea:
--   • tabla `appointments` con las citas
--   • Row Level Security: el público solo INSERTA; el dueño (con sesión) lee/edita
--   • dos funciones SECURITY DEFINER para que el público vea huecos ocupados
--     SIN exponer nombres/emails/teléfonos
--   • índices para el cron de recordatorios
--
-- Después, crea el usuario del dueño en Authentication → Users → Add user
-- (con su email y una contraseña; con esos entrará al panel).

create table if not exists public.appointments (
  id             text primary key,
  date           text not null,                 -- YYYY-MM-DD
  time           text not null,                 -- HH:mm
  service        text not null,
  client_name    text not null,
  client_email   text not null,
  client_phone   text not null,
  notes          text default '',
  status         text not null default 'confirmed',
  reminder_sent  boolean not null default false,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

-- actualiza updated_at en cada cambio (útil para trazabilidad)
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists trg_appointments_updated_at on public.appointments;
create trigger trg_appointments_updated_at
before update on public.appointments
for each row execute function public.set_updated_at();

-- índice para el cron (citas confirmadas sin avisar)
create index if not exists appointments_reminder_idx
  on public.appointments (status, reminder_sent, date, time)
  where status = 'confirmed' and reminder_sent = false;

-- ── Row Level Security ──
alter table public.appointments enable row level security;

-- cualquiera (anon) puede crear una cita
drop policy if exists "public can insert" on public.appointments;
create policy "public can insert" on public.appointments
  for insert to anon, authenticated
  with check (true);

-- solo el dueño autenticado ve / modifica / borra
drop policy if exists "owner can select" on public.appointments;
create policy "owner can select" on public.appointments
  for select to authenticated using (true);

drop policy if exists "owner can update" on public.appointments;
create policy "owner can update" on public.appointments
  for update to authenticated using (true);

drop policy if exists "owner can delete" on public.appointments;
create policy "owner can delete" on public.appointments
  for delete to authenticated using (true);

-- ── Funciones públicas (no exponen PII) ──
-- Horas ocupadas de un día concreto.
create or replace function public.booked_slots(p_date text)
returns text[] language sql security definer set search_path = public as $$
  select coalesce(array_agg(time order by time), '{}')
  from public.appointments
  where date = p_date and status = 'confirmed';
$$;

-- Conteo de citas por día en un rango (para los puntitos del calendario).
create or replace function public.booked_counts(p_from text, p_to text)
returns table (date text, cnt bigint) language sql security definer set search_path = public as $$
  select date, count(*) as cnt
  from public.appointments
  where date between p_from and p_to and status = 'confirmed'
  group by date;
$$;

grant execute on function public.booked_slots(text)         to anon, authenticated;
grant execute on function public.booked_counts(text, text)  to anon, authenticated;
