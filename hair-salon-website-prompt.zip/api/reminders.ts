// ─── Recordatorios automáticos 24 h antes ──────────────────────────────────
// Función serverless de Vercel. La ejecuta Vercel Cron cada hora (ver vercel.json).
// Recorre las citas confirmadas que empiezan en ~24 h y aún no se avisaron,
// envía un SMS (o WhatsApp) al cliente por Twilio y marca `reminder_sent`.
//
// Variables de entorno en Vercel (Settings → Environment Variables):
//   CRON_SECRET              texto aleatorio que tú elijas (protege el endpoint)
//   SUPABASE_URL             https://xxxx.supabase.co
//   SUPABASE_SERVICE_ROLE_KEY  la "service_role" (SECRETA; solo aquí, nunca en el cliente)
//   TWILIO_ACCOUNT_SID       de tu cuenta Twilio
//   TWILIO_AUTH_TOKEN        de tu cuenta Twilio
//   TWILIO_FROM              número E.164 origen para SMS (p. ej. +14155550123)
//   REMINDER_CHANNEL         "sms" (por defecto) o "whatsapp"
//   TWILIO_WA_FROM           número origen de WhatsApp (solo si channel=whatsapp)
//
// Nota WhatsApp: Twilio/WhatsApp exige una PLANTILLA aprobada por Meta para
// mensajes proactivos; si no la tienes, usa REMINDER_CHANNEL=sms (texto libre).

export default async function handler(req: any, res: any) {
  // 1) solo Vercel Cron (o quien tenga el secreto) puede disparar esto
  const secret = process.env.CRON_SECRET || "";
  const auth = req.headers["authorization"] || req.headers["Authorization"] || "";
  if (!secret || auth !== `Bearer ${secret}`) {
    return res.status(401).json({ ok: false, error: "unauthorized" });
  }

  const SUPA = (process.env.SUPABASE_URL || "").replace(/\/$/, "");
  const ROLE = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
  if (!SUPA || !ROLE) return res.status(500).json({ ok: false, error: "supabase env missing" });

  // 2) ventana: citas que empiezan en 24 h (±30 min para no pasarnos con el cron horario)
  const now = new Date();
  const center = new Date(now.getTime() + 24 * 3600 * 1000);
  const from = new Date(center.getTime() - 30 * 60 * 1000);
  const to = new Date(center.getTime() + 30 * 60 * 1000);
  const dates = Array.from(new Set([now, center, from, to].map((d) => d.toISOString().slice(0, 10))));

  const head = { apikey: ROLE, Authorization: `Bearer ${ROLE}`, "Content-Type": "application/json" };
  const got = await fetch(
    `${SUPA}/rest/v1/appointments?status=eq.confirmed&reminder_sent=eq.false&date=in.(${dates.join(",")})`,
    { headers: head }
  );
  if (!got.ok) return res.status(500).json({ ok: false, error: "query failed", status: got.status });
  const rows: any[] = await got.json();

  const due = rows.filter((r) => {
    const at = new Date(`${r.date}T${r.time}:00`).getTime();
    return at >= from.getTime() && at <= to.getTime();
  });

  // 3) enviar y marcar
  const channel = (process.env.REMINDER_CHANNEL || "sms").toLowerCase();
  const results: { id: string; client: string; sent: boolean; err?: string }[] = [];
  for (const r of due) {
    let sent = false;
    let err = "";
    try {
      sent = await sendReminder(r, channel);
    } catch (e: any) {
      err = String(e?.message || e);
    }
    if (sent) {
      await fetch(`${SUPA}/rest/v1/appointments?id=eq.${encodeURIComponent(r.id)}`, {
        method: "PATCH",
        headers: head,
        body: JSON.stringify({ reminder_sent: true }),
      });
    }
    results.push({ id: r.id, client: r.client_name, sent, err });
  }

  return res.status(200).json({ ok: true, checked: rows.length, due: due.length, results });
}

function digits(p: string): string {
  const d = (p || "").replace(/[^\d]/g, "");
  if (!d) return "";
  return d.length === 9 ? "34" + d : d; // asume España si vienen 9 dígitos
}
function e164(p: string): string { const d = digits(p); return d ? "+" + d : ""; }

function reminderText(r: any): string {
  const fecha = new Date(`${r.date}T12:00:00`).toLocaleDateString("es-ES", {
    weekday: "long", day: "numeric", month: "long",
  });
  return (
    `Hola ${r.client_name}, te recordamos tu cita en VELURE Barber Co. el ` +
    `${fecha} a las ${r.time}. Si necesitas cambiarla, llámanos o responde a este mensaje. ¡Gracias!`
  );
}

// ── SMS (Twilio): fiable y texto libre ──
async function sendTwilioSms(r: any): Promise<boolean> {
  const SID = process.env.TWILIO_ACCOUNT_SID || "";
  const TOK = process.env.TWILIO_AUTH_TOKEN || "";
  if (!SID || !TOK) throw new Error("TWILIO env missing");
  const to = e164(r.client_phone);
  if (!to) throw new Error("bad phone");
  const params = new URLSearchParams({ To: to, From: process.env.TWILIO_FROM || "", Body: reminderText(r) });
  const resp = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${SID}/Messages.json`, {
    method: "POST",
    headers: { Authorization: "Basic " + Buffer.from(`${SID}:${TOK}`).toString("base64"), "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  if (!resp.ok) throw new Error("twilio sms " + resp.status);
  return true;
}

// ── WhatsApp oficial (Twilio): robusto, pero el proactivo exige plantilla aprobada ──
async function sendTwilioWa(r: any): Promise<boolean> {
  const SID = process.env.TWILIO_ACCOUNT_SID || "";
  const TOK = process.env.TWILIO_AUTH_TOKEN || "";
  if (!SID || !TOK) throw new Error("TWILIO env missing");
  const to = e164(r.client_phone);
  if (!to) throw new Error("bad phone");
  const params = new URLSearchParams({
    To: `whatsapp:${to}`, From: `whatsapp:${process.env.TWILIO_WA_FROM || ""}`, Body: reminderText(r),
  });
  const resp = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${SID}/Messages.json`, {
    method: "POST",
    headers: { Authorization: "Basic " + Buffer.from(`${SID}:${TOK}`).toString("base64"), "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  if (!resp.ok) throw new Error("twilio wa " + resp.status);
  return true;
}

// ── WhatsApp por QR (UltraMsg): rápido, texto libre, sin plantilla aprobada ──
// Conecta el WhatsApp del salón con un QR; envía como si escribieras tú.
// Ojo: vía no oficial → usa frecuencias sensatas para no arriesgar el número.
async function sendUltraMsg(r: any): Promise<boolean> {
  const inst = process.env.ULTRAMSG_INSTANCE || "";
  const tok = process.env.ULTRAMSG_TOKEN || "";
  if (!inst || !tok) throw new Error("ULTRAMSG env missing");
  const to = digits(r.client_phone); // UltraMsg: prefijo + número, sin "+"
  if (!to) throw new Error("bad phone");
  const params = new URLSearchParams({ token: tok, to, body: reminderText(r), priority: "10" });
  const resp = await fetch(`https://api.ultramsg.com/${inst}/messages/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  if (!resp.ok) throw new Error("ultramsg " + resp.status);
  const j = await resp.json().catch(() => ({} as any));
  if (j && (j.error || j.success === false)) throw new Error("ultramsg: " + JSON.stringify(j));
  return true;
}

// WhatsApp oficial (Meta Cloud API) con plantilla aprobada. Reproduce el "bot"
// que nos pasaste: mismo endpoint, mismo payload y mismo orden de {{1}}..{{6}}.
async function sendMetaWa(r: any): Promise<boolean> {
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID || "";
  const token = process.env.WHATSAPP_TOKEN || "";
  if (!phoneId || !token) throw new Error("META wa env missing");
  const to = digits(r.client_phone); // formato internacional sin "+"
  if (!to) throw new Error("bad phone");
  const api = process.env.META_API_VERSION || "v20.0";
  const fecha = new Date(`${r.date}T12:00:00`).toLocaleDateString("es-ES", {
    weekday: "long", day: "numeric", month: "long",
  });
  const nombreSalon = process.env.SALON_NAME || "VELURE Barber Co.";
  const direccion = process.env.SALON_ADDRESS || "Calle de la Belleza, 42, 28001 Madrid";
  const telefonoContacto = process.env.SALON_PHONE_DISPLAY || "+34 912 345 678";

  const payload = {
    messaging_product: "whatsapp",
    to,
    type: "template",
    template: {
      name: process.env.TEMPLATE_NAME || "recordatorio_cita",
      language: { code: process.env.TEMPLATE_LANG || "es" },
      components: [
        {
          type: "body",
          parameters: [
            { type: "text", text: String(r.client_name || "") },   // {{1}}
            { type: "text", text: nombreSalon },                  // {{2}}
            { type: "text", text: fecha },                        // {{3}}
            { type: "text", text: String(r.time || "") },         // {{4}}
            { type: "text", text: direccion },                    // {{5}}
            { type: "text", text: telefonoContacto },             // {{6}}
          ],
        },
      ],
    },
  };

  const resp = await fetch(`https://graph.facebook.com/${api}/${phoneId}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!resp.ok) {
    const t = await resp.text().catch(() => "");
    throw new Error(`meta wa ${resp.status} ${t.slice(0, 200)}`);
  }
  const data = await resp.json().catch(() => ({} as any));
  if (data && data.error) throw new Error("meta wa: " + JSON.stringify(data.error));
  return true;
}

// Despacho por canal. En WhatsApp, por prioridad: bot oficial de Meta
// (plantilla aprobada) → UltraMsg (QR) → Twilio WhatsApp.
async function sendReminder(r: any, channel: string): Promise<boolean> {
  if (channel === "sms") return sendTwilioSms(r);
  if (process.env.WHATSAPP_PHONE_NUMBER_ID && process.env.WHATSAPP_TOKEN) return sendMetaWa(r);
  if (process.env.ULTRAMSG_INSTANCE && process.env.ULTRAMSG_TOKEN) return sendUltraMsg(r);
  return sendTwilioWa(r);
}
